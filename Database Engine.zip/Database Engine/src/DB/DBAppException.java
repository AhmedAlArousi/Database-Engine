package kalabalaDB;

public class DBAppException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DBAppException() {
	}

	public DBAppException(String arg0) {
		super(arg0);
	}


}
